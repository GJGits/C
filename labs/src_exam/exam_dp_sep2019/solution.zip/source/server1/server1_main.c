/*
 * TEMPLATE
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <unistd.h> // for close
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h> 
#include <string.h>
#include <inttypes.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/time.h> 
#include <sys/socket.h>
#include "gj_server.h"
#include "../errlib.h"
#include <arpa/inet.h>
#include <netinet/in.h>

char *prog_name;

int main (int argc, char *argv[])
{	
	
	checkArgc(argc, 2,2,"Usage: <port>");
	int socket = startTcpServer(argv[1]);
	runTcpInstance(socket);
	close(socket);
	return 0;
}