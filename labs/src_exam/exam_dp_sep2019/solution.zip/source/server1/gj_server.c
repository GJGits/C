#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h> 
#include <string.h>
#include <inttypes.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/time.h> 
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/sendfile.h>
#include <netinet/in.h>

#include "../sockwrap.h"
#include "../errlib.h"
#include "gj_server.h"
#include "../gj_tools.h"
#include "../sockwrap.h"
#include "../errlib.h"


#define REQUEST_LEN 100
#define SEND_CHUNK 1024
#define FILE_PATH ""

int startTcpServer(const char* port) {

    uint16_t i_port;
    int sockfd;

    sockfd = Socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    parsePort(port, &i_port);
    bindToAny(sockfd, i_port);
    Listen(sockfd, 516);
    printf("Server[listening]: " ANSI_COLOR_GREEN 
	"PORT = %d, BACKLOG = 516" ANSI_COLOR_RESET "\n", (int) i_port);

    return sockfd;
}

void runTcpInstance(int passiveSock) {

    struct sockaddr_in cli_addr;
    socklen_t addr_len = sizeof(struct sockaddr_in);

    while(1) {
        printf("Server[accepting]: " ANSI_COLOR_YELLOW 
		"WAITING FOR A CONNECTION..." ANSI_COLOR_RESET "\n");
        int connSock = Accept(passiveSock , (struct sockaddr *) &cli_addr, &addr_len);
	printf("Server[link]: " ANSI_COLOR_GREEN "OPENED A CONNECTION" ANSI_COLOR_RESET "\n");
        doTcpJob(connSock);
        close(connSock);
    }

    close(passiveSock);

}


void doTcpJob(int connSock) {

	printf("Server[request]: " ANSI_COLOR_CYAN 
		"WAITING FOR A REQUEST..." ANSI_COLOR_RESET "\n");
	const char *error = "-ERR\r\n";	
	char reqBuffer[REQUEST_LEN] = " ";
	if(doTcpReceive(connSock, reqBuffer) == 0) {
		doTcpSend(connSock, reqBuffer);
		close(connSock);
		return;
	}
    send(connSock, error, 6, 0);
    
    //close(connSock);	
}


int doTcpReceive(int connSock, char *request) {
    // TODO: INSERIRE LOGICA RECEIVE QUI
    struct timeval tval;
    fd_set cset;
    FD_ZERO(&cset);
    FD_SET(connSock, &cset);
    tval.tv_sec = 15;
    tval.tv_usec = 0;

    if(Select(FD_SETSIZE, &cset, NULL, NULL, &tval) == 1) {
	
	const char *get = "GET ";
	const char *quit = "QUIT";

	// LEGGO TIPO RICHIESTA
	char req_type[5] = " ";
        recv(connSock, req_type, 4, 0);
	
	if(strcmp(get, req_type) == 0) {

		const char *end = "\r\n";
		int pos = 2;
		int attempts = 0; // per evitare stuck in while
		
		while(request[pos - 2] != '\r' && request[pos - 1] != '\n' && attempts < 1) {
			ssize_t read = recv(connSock, request, REQUEST_LEN, 0);
			pos = strlen(request);
			//printf("req: %s, pos: %d, read: %d\n", request, pos, (int)read);
			attempts = (read == 0) ? 1 : 0;
		}

		printf("Server[request]: " ANSI_COLOR_CYAN 
			"CLIENT LOOKS FOR -> %s" ANSI_COLOR_RESET , (char *)request);
		return 0;

	}

	else if(strcmp(quit, req_type) == 0){
		close(connSock);
		printf("Server[link]: " ANSI_COLOR_GREEN 
			"QUITTING LINK..." ANSI_COLOR_RESET "\n");
		return -1;
	}

	else {
		printf("Server[request] " ANSI_COLOR_RED 
			"UNKNOWN REQUEST TYPE -> %s" ANSI_COLOR_RESET "\n", req_type);
		close(connSock);
		return -1;
	}
    }

    printf("Server[request]: " ANSI_COLOR_RED 
	"TIMEOUT SCADUTO" ANSI_COLOR_RESET "\n");
    close(connSock);		

    return -1;
}

void doTcpSend(int connSock, char *request) {
	
	const char *error = "-ERR\r\n";
	const char *ok = "+OK\r\n";
	char fname[REQUEST_LEN] = "./server1/";
	memcpy(fname + 10, request, strlen(request) - 2);
	FILE *fp;
	fp = fopen(fname, "rb+");

	if(fp != NULL) {
		
		struct stat fstat;
		uint32_t info = 0;
		
    		if(stat(fname, &fstat) == 0) {
        		info = (uint32_t) htonl(fstat.st_mtime);
			send(connSock, ok, 5, 0);
			size_t sent = 0;
			uint32_t f_size = fstat.st_size;
			itos((int)f_size);
			send(connSock, &f_size, 4, 0);
			char * end = "\r\n";
			send(connSock, end, 2, 0);
			while(sent < f_size) {
				size_t delta = f_size - sent;
				size_t to_send = (delta > SEND_CHUNK) ? SEND_CHUNK : delta;
				sent += sendfile(connSock, fileno(fp), NULL, to_send);
				showProgress((int)sent, (int) f_size, "Server[request]: ");
			}
			send(connSock, &info, 4, 0);
			printf("\n");
			return;
    		}

		printf("Server[error]: " ANSI_COLOR_RED 
			"STAT FAILED -> %s" ANSI_COLOR_RESET "\n", fname);
		send(connSock, error, 6, 0);
		close(connSock);
		return;
	}

	printf("Server[error]: " ANSI_COLOR_RED 
		"FILE NOT FOUND -> %s\n" ANSI_COLOR_RESET "\r", fname);
	send(connSock, error, 6, 0);
	close(connSock);

}

char *itos(int num) {
	char str_num[10] = " ";
	char *nums[10];
	int num1 = num;
	nums[0] = "0";
	nums[1] = "1";
	nums[2] = "2";
	nums[3] = "3";
	nums[5] = "4";
	nums[6] = "5";
	nums[7] = "6";
	nums[8] = "7";
	nums[9] = "8";
	nums[10] = "9";
	int div = 11;
	int count = 0;
	while (num1 > 10) {
		count++;
		num1 = num1/10;
	}
	div = 11;
	while(num > 10) {
		int resto = num % 10;
		str_num[count] = nums[resto];
		num = num / 10;
		count--;
	}
	printf("test: %s\n", str_num);
	return str_num;
}

