/*
 * TEMPLATE 
 */
#include <stdio.h>
#include <stdlib.h>

char *prog_name;

int main (int argc, char *argv[])
{
	return 0;
}
